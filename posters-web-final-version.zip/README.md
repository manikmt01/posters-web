# posters-web

## Login:

1. https://manikmt01.github.io/posters-web/login.html
   https://manikmt01.github.io/posters-web/register.html
   https://manikmt01.github.io/posters-web/email_Verification.html
   https://manikmt01.github.io/posters-web/select-Community.html
   https://manikmt01.github.io/posters-web/terms-Conditions.html

2. https://manikmt01.github.io/posters-web/privacy-Policies.html

3. https://manikmt01.github.io/posters-web/email-Template.html

## Feed UIs:

1. https://manikmt01.github.io/posters-web/feed-sponser-post.html => (Feed_Sponser Post + Project Feed Page_Requests + Project Feed Page_Deals)

2. https://manikmt01.github.io/posters-web/project_Feed_Page_Companies.html

3. https://manikmt01.github.io/posters-web/feed_Comments.html (Feed_Comments + Feed_Comments_Sort + Project_Notifications)

4. https://manikmt01.github.io/posters-web/feed_Set Loacation_Search.html

5. https://manikmt01.github.io/posters-web/feed_Set-Loacation_Search_Realtime.html
6. https://manikmt01.github.io/posters-web/feed_Sponser-Post-View.html
7. https://manikmt01.github.io/posters-web/feed_Click-on-video-post.html
8. https://manikmt01.github.io/posters-web/feed_Click-on-video.html

## Post Something:

1. https://manikmt01.github.io/posters-web/feed_Create-Post.html
2. https://manikmt01.github.io/posters-web/post_Something_Upload_Photo.html
3. https://manikmt01.github.io/posters-web/post_Something_Upload_Photo-scan.html
4. https://manikmt01.github.io/posters-web/post-details-auto-captured.html
   https://manikmt01.github.io/posters-web/post-details-auto-captured_Location_Expand.html
   https://manikmt01.github.io/posters-web/post-details-auto-captured_Location-Mobile.html
   https://manikmt01.github.io/posters-web/post-details-auto-captured_Location-Mobile-Expand.html
   https://manikmt01.github.io/posters-web/post-details-auto-captured_Location_WW.html
   https://manikmt01.github.io/posters-web/post-details-auto-captured_Location-WW-Expand.html
   https://manikmt01.github.io/posters-web/post_Something_Enter_Details.html
   https://manikmt01.github.io/posters-web/post-Something_Enter-Details_2_Select-Community.html
   https://manikmt01.github.io/posters-web/post-Something_Enter-Details_2_Post-As.html
   https://manikmt01.github.io/posters-web/post-Successful.html

## Post Scenarios:

1. https://manikmt01.github.io/posters-web/feed_Post_Scenario-1.html
2. https://manikmt01.github.io/posters-web/feed_Post_Scenario-2.html
3. https://manikmt01.github.io/posters-web/feed_Post_Scenario-3.html
4. https://manikmt01.github.io/posters-web/feed_Post_Scenario-4.html
5. https://manikmt01.github.io/posters-web/feed_Post_Scenario-5.html
6. https://manikmt01.github.io/posters-web/feed_Post_Scenario-6.html
7. https://manikmt01.github.io/posters-web/feed_Post_Scenario-7.html
8. https://manikmt01.github.io/posters-web/feed_Post_Scenario-8.html
9. https://manikmt01.github.io/posters-web/feed_Post_Scenario-9.html

## Deal & Shared Deal:

1. https://manikmt01.github.io/posters-web/feed-Create-Deal.html
2. https://manikmt01.github.io/posters-web/Create-Deal.html
   https://manikmt01.github.io/posters-web/view-Deal-Details.html
3. https://manikmt01.github.io/posters-web/view-Shared-Deal-Details.html
4. https://manikmt01.github.io/posters-web/view-Shared-Deal-Details-2.html

## I’m Listing:

1. https://manikmt01.github.io/posters-web/feed-im-looking-for.html
2. https://manikmt01.github.io/posters-web/im-looking-for-view-redesigned-enter-details.html
   https://manikmt01.github.io/posters-web/im-Looking-For_View-Redesigned_Enter-Details_select-comunity.html
   https://manikmt01.github.io/posters-web/post-Successful.html

## Convert to Ad:

1. https://manikmt01.github.io/posters-web/feed-boost-post.html
2. https://manikmt01.github.io/posters-web/feed-boost-post-convert.html
   https://manikmt01.github.io/posters-web/create-ads-upload-pic-convert.html
   https://manikmt01.github.io/posters-web/create-ad-enter-details-convert.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-one-convert.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-two-convert.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-three-convert.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-four-convert.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-five-convert.html
3. https://manikmt01.github.io/posters-web/create-ads-upload-payment-new-convert.html
   https://manikmt01.github.io/posters-web/create-ads-upload-payment-successfull-convert.html

## Create Ad:

1. https://manikmt01.github.io/posters-web/feed_Create-ads.html
2. https://manikmt01.github.io/posters-web/create-ads-upload-pic.html
   https://manikmt01.github.io/posters-web/create-ad-connect-to-existing-company.html
   https://manikmt01.github.io/posters-web/create-ad-connect-to-existing-company-verify.html
   https://manikmt01.github.io/posters-web/create-ad-enter-details-new.html
   https://manikmt01.github.io/posters-web/create-ad_enter-details_If-service-provider_select-community.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-one.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-two.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-three.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-four.html
   https://manikmt01.github.io/posters-web/Create-ad-more-2-2-scenario-five.html
3. https://manikmt01.github.io/posters-web/create-ads-upload-payment-new.html
   https://manikmt01.github.io/posters-web/create-ads-upload-payment-successfull-new .html

4. https://manikmt01.github.io/posters-web/my-profile-sponsor.html
5. https://manikmt01.github.io/posters-web/my-profile-favorite-post.html
6. https://manikmt01.github.io/posters-web/my-profile-drafts-posts.html
7. https://manikmt01.github.io/posters-web/my-profile-drafts-ads.html
8. https://manikmt01.github.io/posters-web/my-profile-drafts-looking-for.html
9. https://manikmt01.github.io/posters-web/my-profile-drafts-deals.html
10. https://manikmt01.github.io/posters-web/my-profile-recommends.html
11. https://manikmt01.github.io/posters-web/update-account.html

## Boost Post (V1)

1. https://manikmt01.github.io/posters-web/feed-boost-post.html
2. https://manikmt01.github.io/posters-web/feed-boost-post-overlay.html
   https://manikmt01.github.io/posters-web/boost-post-create-ad-details-new.html
   https://manikmt01.github.io/posters-web/boost-post-preview-one.html
   https://manikmt01.github.io/posters-web/boost-post-preview-two.html
   https://manikmt01.github.io/posters-web/boost-post-preview-three.html

3. https://manikmt01.github.io/posters-web/feed_Create-ads-empty.html
4. https://manikmt01.github.io/posters-web/feed-running-ads-post-sponsorship-rejected-by-admin.html
5. https://manikmt01.github.io/posters-web/feed-running-ads-post-sponsorship-rejected-byadmin.html
